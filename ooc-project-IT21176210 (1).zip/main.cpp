//Admin & Report codes
#include <iostream>
#include <cstring>
#include "Admin.h"
#include "Report.h"
using namespace std;
int main() {
Report rpNo;

rpNo.Reports(4197392, (char*)"CUSTOMR REPORTS"); rpNo.displayReport();

cout << "\n" << endl;
cout << "--------------------------------" << endl;

Admin ADNo;
ADNo.Admins(4, (char*)"Nimal");
ADNo.displayAdmin();

cout << "\n" << endl;
cout << "--------------------------------" << endl;

}