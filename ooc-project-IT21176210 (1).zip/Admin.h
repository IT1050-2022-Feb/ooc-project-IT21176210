class Admin
{
private:
int AdminID;
char name[25];

public:
void Admins(int ADNo, char ADName[]);
void displayAdmin();
};