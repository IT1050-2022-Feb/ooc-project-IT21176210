class Report
{
private:
int ReportNo;
char name[25];

public:
void Reports(int rpNo, char reportName[]);
void displayReport();
};
